<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>advice-disclaimer</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Advice Disclaimer</h1>
				<p>We provide narratives on our products along with guidance from various sources (identified by individual, when available) for informational purposes and is not meant to substitute for the advice provided by your own physician or health care provider. You should not use the information contained herein for diagnosing or treating a health problem or disease, or prescribing any medication. You should read all product packaging carefully. If you have, or suspect you have, a medical problem promptly contact your physician or health care provider. Our statements have not been evaluated by the Food and Drug Administration. This product and/or these statements are not intended to diagnose, treat, cure or prevent any disease. The efficacy of this product has not been confirmed by research, and traditional use does not establish that this product will achieve any claimed result.</p>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>