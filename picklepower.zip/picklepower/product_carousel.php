<div class="container">
  <div class="row">
    <h2 class="sec_head">Product Focus</h2>
    <span class="shadow-head"><img src="assets/img/shadow.png" height="20" alt=""></span>
  </div>
</div>
<div class="carousel-reviews broun-block">
  <div class="container">
    <div class="row">
      <div id="carousel-reviews" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="item active"> 
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <!-- BEGIN PRODUCTS -->
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 product-item">
              <span class="thumbnail pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" height="400" width="500" alt="...">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </span>
              <h3><a href="single-product">12 Pack of 8oz Pickle Juice</a></h3>
              <div class="ratings"> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star"></span> <span class="glyphicon glyphicon-star-empty"></span> </div>
              <p>100% natural product, No artificial colors or flavors, Product is clear in color,  sport – 100% natural</p>
              <hr class="line">
              <div class="row">
                <div class="col-md-6 col-sm-6">
                  <p class="pi-price">$19.99</p>
                </div>
                <div class="col-md-6 col-sm-6">
                  <a href="single-product" class="btn add2cart right">BUY ITEM</a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-arrow">
          <a class="left-carousel-control" href="#carousel-reviews" role="button" data-slide="prev"> <span class="left-arrow glyphicon glyphicon-chevron-left"></span> </a> <a class="right-carousel-control" href="#carousel-reviews" role="button" data-slide="next"> <span class="right-arrow glyphicon glyphicon-chevron-right"></span> </a>
        </div>
      </div><!-- carousel slide -->
    </div>
  </div>
</div>