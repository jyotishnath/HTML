<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>regulatory-information</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Regulatory Information</h1>
				<h2>Process Authority and Regulation</h2>
				<p>Our manufacturing facility is under the jurisdiction of (and randomly inspected by) the United States Food and Drug Administration (FDA) and the Texas Department of State Health Services Manufactured Foods Division. Our food manufacturing License Number is 1014917. Our FDA Food Facility Registration Number is 14758132532. The water purification process is under the supervision of our employee certified by the Texas Department of State Health Services under License Number BVW1000426.</p>
				<h2>Licenses and Permits</h2>
				<h2>Internet Sales Refund Policy</h2>
				<p>Products that have been paid for but not yet shipped are available for a 100% refund of product and outbound shipping charges. Provision of a reason for refund is not required. You must notify us as quickly as possible because orders are customarily shipped the day the order is received. Immediate reaction to your request is not guaranteed because of a possible conflict with our normal daily responsibilities.</p>
				<p>If an order has been shipped then a (partial or full) refund on the product may be granted but the outbound shipping charges will not be refunded.  A suitable reason for the refund must be provided to us by email within thirty (30) days of the original outbound shipping date and its acceptance will be at the sole discretion of The Pickle Juice Company.  Complaint about the flavor profile will not qualify as a valid reason for refund.</p>
				<p>Product that has been shipped must be returned to The Pickle Juice Company at the customer’s expense within forty (40) days of the original outbound shipping date. The Pickle Juice Company will determine, at its sole discretion, if the product was returned in suitable condition. Precaution should be taken in packaging to ensure the parcel will protect the product and it is suitable for shipping.</p>
				<p>Once the product has been received, with inbound shipping charges paid by the customer, a determination will be made regarding the reason for refund request, the suitability of returned product, and compliance with time limits. Within ten (10) days after return receipt of the product an appropriate refund may then be credited back to the bank card originally used for the purchase transaction. If a refund is denied then an email will be sent to the customer outlining the reason(s) for the denial.</p>
				<h2>Recycling Policy</h2>
				<p class="yellow-text">Status of Recyclable Packaging</p>
				<p>The Pickle Juice Company is intrinsically connected to nature and the Earth through the purified water we produce to begin our formulations. Our responsibility extends beyond our commitment to provide our customers with superior beverages. We recognize the serious circumstance of increased pollution of our planet and the negative consequences thereof.</p>
				<p>As a result we are proud to state that we have aligned ourselves with packaging manufacturers who share our environmental concern and provide us with materials that are reusable and/or recyclable. The following is a description of the packaging materials we employ and their reuse and recycling status.</p>
				<table class="table table-responsive">
				    <thead>
				      <tr>
				        <th>Packaging Item</th>
				        <th>Material of Manufacturer</th>
				        <th>Recycle</th>
				        <th>Designation</th>
				        <th>Recyclable</th>
				      </tr>
				    </thead>
				    <tbody>
				      <tr>
				        <td>2.5 ounce plastic bottle</td>
				        <td>PET Polyethylene Terephthalate</td>
				        <td>1 – PETE</td>
				        <th></th>
				        <td>Recyclable</td>
				      </tr>
				      <tr>
				        <td>8 ounce plastic bottle</td>
				        <td>PET Polyethylene Terephthalate</td>
				        <th>1 – PETE</th>
				        <th></th>
				        <td>Recyclable</td>
				      </tr>
				      <tr>
				        <td>16 ounce plastic bottle</td>
				        <td>PET Polyethylene Terephthalate</td>
				        <td>1 – PETE</td>
				        <td></td>
				        <td>Recyclable</td>
				      </tr>
				      <tr>
				        <td>28 mm bottle closure</td>
				        <td>Polypropylene</td>
				        <td>5 – PP</td>
				        <td></td>
				        <td>Recyclable</td>
				      </tr>
				      <tr>
				        <td>Shrink bundle plastic</td>
				        <td>LDPE Low Density Polyethylene</td>
				        <td>4 – LDPE</td>
				        <td></td>
				        <td>Recyclable</td>
				      </tr>
				      <tr>
				      	<td>Paperboard case</td>
				      	<td>Paper</td>
				      	<td>Paper</td>
				      	<td></td>
				      	<td>Recyclable</td>
				      </tr>
				    </tbody>
				  </table>
				  <p>We are committed to ecological responsibility and we will continue to explore ackaging materials that functionally improve our environment.</p>
				  <P>Thank you.</P>
				  <P class="yellow-text">Steve Collette</P>
				  <P>Vice President</P>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>