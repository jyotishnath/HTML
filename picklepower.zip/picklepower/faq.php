<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>faq</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>FAQ</h1>
				<!-- Accordian -->
          <div class="accordion">
            <dl>
              <dt>
                <a href="#accordion1" aria-expanded="false" aria-controls="accordion1" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> Does it really taste like pickle juice?</a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion1" aria-hidden="true">
                <p><span class="yellow-text">A:</span> Yes it does. one of the primary reasons that Pickle Juice is so effective in dealing with muscle cramps is due to the ingredients that provide it’s distinctive flavor profile.</p>
              </dd>
              <dt>
                <a href="#accordion2" aria-expanded="false" aria-controls="accordion2" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> Where can I get it?</a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion2" aria-hidden="true">
                <p><span class="yellow-text">A:</span> If your local sporting goods, grocery, bike shop or mass merchant store doesn’t carry our product, you can order from our website or one of several online retail partners. We are always adding new retailers so please ask your local shop to support our product.</p>
              </dd>
              <dt>
                <a href="#accordion3" aria-expanded="false" aria-controls="accordion3" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> Where do you ship?</a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion3" aria-hidden="true">
                <p><span class="yellow-text">A:</span> We will ship our products anywhere in the world as long as there are no import restrictions or trade embargo preventing us from doing so legally. Shipping costs, however, will vary depending on where we are sending our products.</p>
              </dd>
            <dt>
                <a href="#accordion4" aria-expanded="false" aria-controls="accordion4" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> Is it the same as drinking Pickle Juice from the Jar?</a>
              </dt>
              <dd class="accordion-content accordionItem is-collapsed" id="accordion4" aria-hidden="true">
                <p><span class="yellow-text">A:</span> No. Our product is specifically formulated for the dual purpose of addressing muscle cramps and serving as a tool to aid hydration. We have purified and fortified the ingredients in order to provide the most effective product possible while limiting any unnecessary additives.</p>
              </dd>
	            <dt>
	                <a href="#accordion5" aria-expanded="false" aria-controls="accordion5" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> What’s the shelf life?</a>
	            </dt>
	            <dd class="accordion-content accordionItem is-collapsed" id="accordion5" aria-hidden="true">
	                <p><span class="yellow-text">A:</span> Pickle Juice Sport and Pickle Juice Shots have a 2 year published shelf life from the date of manufacture.</p>
	            </dd>
	            <dt>
	                <a href="#accordion6" aria-expanded="false" aria-controls="accordion6" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> Does it have to be refrigerated?</a>
	            </dt>
	            <dd class="accordion-content accordionItem is-collapsed" id="accordion6" aria-hidden="true">
	                <p><span class="yellow-text">A:</span> No, while some of our consumers prefer the product chilled, it is completely shelf stable and does not require refrigeration.</p>
	            </dd>
	            <dt>
	                <a href="#accordion7" aria-expanded="false" aria-controls="accordion7" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> How much should I drink?</a>
	            </dt>
	            <dd class="accordion-content accordionItem is-collapsed" id="accordion7" aria-hidden="true">
	                <p><span class="yellow-text">A:</span> Practical applications and research have found that the neural inhibitors can be triggered by consuming roughly 1 fluid ounce of Pickle Juice per 75 lbs of body weight every 45 minutes from the first sign of muscle cramps during strenuous activity or one time if treating nocturnal leg cramps.</p>
	            </dd>
	            <dt>
	                <a href="#accordion8" aria-expanded="false" aria-controls="accordion8" class="accordion-title accordionTitle js-accordionTrigger"><span class="white-text">Q:</span> When should I drink it?</a>
	            </dt>
	            <dd class="accordion-content accordionItem is-collapsed" id="accordion8" aria-hidden="true">
	                <p><span class="yellow-text">A:</span> Pickle Juice can be taken prior to exercise in order to load up on electrolytes to help maintain adequate hydration levels but should be taken at the first sign of cramping (typically rapid fire muscle “twinging” precedes full blown cramps) to prevent the cramp or while cramping to stop it.</p>
	            </dd>
            </dl>
          </div>
				<!-- End Accordian -->
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>