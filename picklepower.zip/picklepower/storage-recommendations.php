<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>storage-recommendations</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Storage Recommendations</h1>

				<p>Because Pickle Juice® is a food designed for human consumption we have the following recommendations for optimum storage:</p>
				<ul>
					<li>No refrigeration required (though it may be refrigerated)</li>
					<li>Store away from excessive heat in a cool, dry place</li>
					<li>Do not freeze in original bottle (though it may be frozen in appropriate containers)</li>
					<li>Rotate stock according to production code date (use oldest product first)</li>
					<li>Recap containers – do not leave open</li>
				</ul>
				<p>Pickle Juice® has an extended shelf life of two years due to the ingredients of salt and vinegar which are natural preservatives producing a low pH.  A “Best By” date is indelibly printed on every bottle for easy reference.</p>
			</div><!-- Left Section -->
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>




div.sap>div.dhaj>ul.test>li.item$@*4>a[#]{hfdhalkfhlajk}




