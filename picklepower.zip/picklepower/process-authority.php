<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>process-authority-and-regulation</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Process Authority and Regulation</h1>
				<p>Our manufacturing facility is under the jurisdiction of (and randomly inspected by) the United States Food and Drug Administration (FDA) and the Texas Department of State Health Services Manufactured Foods Division. Our food manufacturing License Number is 1014917. Our FDA Food Facility Registration Number is 14758132532. The water purification process is under the supervision of our employee certified by the Texas Department of State Health Services under License Number BVW1000426.</p>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>