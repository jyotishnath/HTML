<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>shop</li>
				</ul>
			</div>
			<div class="col-md-12 page-content">
				<h1>Our Products</h1>
				<div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
              <div class="sticker sticker-new"></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="product-item">
              <div class="pi-img-wrapper">
                <img src="assets/products/12-pk-nat-unwrapped-1-500x400.png" class="img-responsive" alt="12 PACK OF 8OZ PICKLE JUICE">
                <div>
                  <a href="#" class="btn">Zoom</a>
                  <a href="single-product" class="btn">View</a>
                </div>
              </div>
              <h3><a href="single-product">12 PACK OF 8OZ PICKLE JUICE</a></h3>
              <div class="pi-price">$29.00</div>
              <a href="javascript:;" class="btn add2cart">Add to cart</a>
            </div>
        </div>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>