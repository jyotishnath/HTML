<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="index">Home /</a></li>
					<li>single-product</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>12 PACK OF 8OZ PICKLE JUICE</h1>
				<div class="card">
                <div class="preview col-md-6">
                    <div id='carousel-custom' class='carousel slide' data-ride='carousel'>
                        <div class='carousel-outer'>
                            <!-- me art lab slider -->
                            <div class='carousel-inner '>
                                <div class='item active'>
                                    <img src='assets/products/2oz.png' alt='' />
                                </div>
                                <div class='item'>
                                    <img src='assets/products/12-pk-nat-unwrapped-1-500x400.png' alt='' />
                                </div>
                                <div class='item'>
                                    <img src='assets/products/12x16oz2-500x400.png' alt='' />
                                </div>
                                <div class='item'>
                                    <img src='assets/products/48pack.png' alt='' />
                                </div>
                            </div>
                            <!-- sag sol -->
                            <a class='left carousel-control' href='#carousel-custom' data-slide='prev'>
                                <span class='glyphicon glyphicon-chevron-left'></span>
                            </a>
                            <a class='right carousel-control' href='#carousel-custom' data-slide='next'>
                                <span class='glyphicon glyphicon-chevron-right'></span>
                            </a>
                        </div>
                        <!-- thumb -->
                        <ol class='carousel-indicators mCustomScrollbar meartlab'>
                            <li data-target='#carousel-custom' data-slide-to='0' class='active'><img src='assets/products/2oz.png' alt='' /></li>
                            <li data-target='#carousel-custom' data-slide-to='1'><img src='assets/products/12-pk-nat-unwrapped-1-500x400.png' alt='' /></li>
                            <li data-target='#carousel-custom' data-slide-to='2'><img src='assets/products/12x16oz2-500x400.png' alt='' /></li>
                            <li data-target='#carousel-custom' data-slide-to='3'><img src='assets/products/48pack.png' alt='' /></li>
                        </ol>
                    </div>
                </div>
                <div class="details col-md-6">
                	<h3><span class="yellow-text">Product Description</span></h3>
                    <p class="product-description">Suspendisse quos? Tempus cras iure temporibus? Eu laudantium cubilia sem sem! Repudiandae et! Massa senectus enim minim sociosqu delectus posuere.</p>
                    <p class="price">current price: <span>$180</span></p>
                    <div class="rating">
                        <div class="stars">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                        </div>
                        <span class="review-no">41 reviews</span>
                    </div>
                    <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
                    <p class="vote"><strong>SKU:</strong> 01p13</p>
                    <div class="action">
                        <button class="btn add2cart" type="button">add to cart</button>
                        <button class="btn add2cart" type="button">Buy Now	</button>
                    </div>
                    <div class="adi-info">
						<h3><span class="yellow-text">Additional Information</span></h3>
						<ul>
							<li><strong>Weight:</strong> 7.5 lbs</li>
							<li><strong>Dimensions:</strong> 10 x 7.5 x 7 in</li>
						</ul>
					</div>
                </div>
            </div>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>