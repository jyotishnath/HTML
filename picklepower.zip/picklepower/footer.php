<footer>
	<div class="container">
		<div class="row row-centered">
			<div class="col-md-12 col-centered">
				<ul class="social-media">
					<li><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i><p>Facebook</p></a></li>
					<li><a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i><p>Twitter</p></a></li>
					<li><a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i><p>Instagram</p></a></li>
					<li><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i><p>Linkedin</p></a></li>
					<li><a href="#" target="_blank"><i class="fa fa-calendar" aria-hidden="true"></i><p>Event Calender</p></a></li>
					<li><a href="#" target="_blank"><i class="fa fa-address-card-o" aria-hidden="true"></i><p>Contact Us</p></a></li>
				</ul>
			</div>
		</div>
	</div> <!-- Container -->
	<div class="footer-top">
		<div class="container">
			<!-- Footer Bottom -->
		<div class="row">
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <h3>About Us</h3>
                    <ul>
                        <li> <a href="#">Company Profile</a> </li>
                        <li> <a href="#">International</a> </li>
                        <li> <a href="#">Quality</a> </li>
                        <li> <a href="#">Terms &amp; Conditions</a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <h3>New &amp; Events</h3>
                    <ul>
                        <li> <a href="#">News</a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <h3>Ask The Experts</h3>
                    <ul>
                        <li> <a href="#">Submit Your Query</a> </li>
                        <li> <a href="#">Faq</a> </li>
                    </ul>
                </div>
                <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6 footer-widget">
                    <h3>Ambassadors</h3>
                    <ul>
                        <li> <a href="#">Individuals</a> </li>
                        <li> <a href="#">Tearms</a> </li>
                        <li> <a href="#">Internation</a> </li>
                    </ul>
                </div>
                <div class="col-lg-3  col-md-3 col-sm-6 col-xs-12 footer-widget">
                    <h3>Join our mailing list</h3>
                    <ul>
                        <li>
                            <div class="input-append newsletter-box text-center">
                                <input type="text" class="full text-center" placeholder="Email ">
                                <button class="btn submit" type="button"> Subscribe <i class="fa fa-long-arrow-right"> </i> </button>
                            </div>
                        </li>
                    </ul>
                    <ul class="social">
                        <li><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
						<li><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						<li><a href="#" target="_blank"><i class="fa fa-calendar" aria-hidden="true"></i></a></li>
						<li><a href="#" target="_blank"><i class="fa fa-address-card-o" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div> <!-- Row -->
            <!-- Footer Bottom End -->
		</div>
	</div>
	<div class="footer-bottom">
        <div class="container">
            <p class="pull-left"> Copyright © Pickle Power <?php echo date("Y"); ?></p>
            <div class="middle-block">
                <ul class="nav nav-pills payments">
                    <li><i class="fa fa-cc-visa"></i></li>
                    <li><i class="fa fa-cc-mastercard"></i></li>
                    <li><i class="fa fa-cc-amex"></i></li>
                    <li><i class="fa fa-cc-paypal"></i></li>
                </ul></div>
            <div class="pull-right designed">
                 <a href="http://www.goigi.com" target="_blank">Designed &amp; Developed by GOIGI</a>
            </div>
        </div>
    </div>
</footer>
<div class="buy-now"><a href="shop"><img src="assets/img/buy-now.png" alt=""></a></div>

</div><!-- Body Bg -->
<script src="assets/js/jquery.min.js"></script>
<scrpt src="assets/js/lightbox-plus-jquery.min.js"></scrpt>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/custom_js.js"></script>
</body>
</html>