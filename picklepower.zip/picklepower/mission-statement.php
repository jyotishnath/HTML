<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>mission-statement</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Mission Statement</h1>
				<p>The Pickle Juice Company is committed to manufacturing the highest quality products designed to prevent or stop muscle cramps. Every employee is bound by a commitment to quality that is a consistent directive from ownership and management. We embrace responsible manufacturing that is designed to protect the environment and promote technologies and components that allow for reuse and recycling of materials. Along with this pledge to quality and the environment we strive to provide excellent service to our customers so consumers may enjoy a superior product dedicated to their well-being.</p>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>