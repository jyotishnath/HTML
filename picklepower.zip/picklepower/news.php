<div class="container">
  <div class="row">
    <h2 class="sec_head">News</h2>
    <span class="shadow-head"><img src="assets/img/shadow.png" height="20" alt=""></span>
  </div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-4 animated fadeIn">
			<a href="#"><img  src="http://lorempixel.com/400/200/sports" class="img-responsive animated fadeIn"></a>
			<h4 class="post-title"><a href="#">Shop online now</a></h4>
		</div>
		<div class="col-md-4 animated fadeIn">
			<a href="#"><img src="http://lorempixel.com/400/200/sports" class="img-responsive animated fadeIn"></a>
			<h4 class="post-title"><a href="#">Shop online now</a></h4>
		</div>
		<div class="col-md-4 animated fadeIn">
			<a href="#"><img src="http://lorempixel.com/400/200/sports" class="img-responsive animated fadeIn"></a>
			<h4 class="post-title"><a href="#">Shop online now</a></h4>
		</div>
		<div class="col-md-4 animated fadeIn">
			<a href="#"><img src="http://lorempixel.com/400/200/sports" class="img-responsive animated fadeIn"></a>
			<h4 class="post-title"><a href="#">Shop online now</a></h4>
		</div>
		<div class="col-md-4 animated fadeIn">
			<a href="#"><img src="http://lorempixel.com/400/200/sports" class="img-responsive animated fadeIn"></a>
			<h4 class="post-title"><a href="#">Shop online now</a></h4>
		</div>
		<div class="col-md-4 animated fadeIn">
			<a href="#"><img src="http://lorempixel.com/400/200/sports" class="img-responsive animated fadeIn"></a>
			<h4 class="post-title"><a href="#">Shop online now</a></h4>
		</div>
	</div>
</div>