<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>
<div class="container">
  <div class="row">
    <div class="col-md-12 page-bg">
      <div class="breadcrub pull-right yellow-text">
        <ul>
          <li><a href="javascript:void(0);">Home /</a></li>
          <li>contact-us</li>
        </ul>
      </div>
      <div class="page-content">
        <div class="col-md-8">
          <h1>Pickle Juice Sport</h1>
          <h3>We are available for your needs. To receive a prompt response to your inquiries, feel free to contact us directly online using the form below…</h3>
          <form role="form">
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="f_name" placeholder="First Name:">
            </div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="l_name" placeholder="Last Name:">
            </div>
            <div class="clearfix"></div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="email" class="form-control custom-form" id="email_address" placeholder="Email Address:">
            </div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="tel" class="form-control custom-form" id="phone_number" placeholder="Phone Number:">
            </div>
            <div class="clearfix"></div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="company" placeholder="Company:">
            </div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="web_address" placeholder="Web Address: https://www.yourdomain.com">
            </div>
            <div class="clearfix"></div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="address1" placeholder="Address Line 1">
            </div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="address2" placeholder="Address Line 2">
            </div>
            <div class="clearfix"></div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="city" placeholder="City">
            </div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="state" placeholder="State">
            </div>
            <div class="clearfix"></div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <input type="text" class="form-control custom-form" id="zip" placeholder="Zip Code">
            </div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <select class="form-control" id="select_learn">
                <option>How did you hear about us?</option>
                <option>Online</option>
                <option>Friends</option>
                <option>Adds</option>
              </select>
            </div>
            <div class="clearfix"></div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <textarea class="form-control" id="message" placeholder="Your message or inquiry:"></textarea>
            </div>
            <div class="form-group col-xs-10 col-sm-6 col-md-6 col-lg-6">
              <select class="form-control" id="select_email">
                <option>To whom send this email?</option>
                <option>Sales</option>
                <option>Admin</option>
                <option>Support</option>
              </select>
            </div>
            <div class="clearfix"></div>
            <div class="col-xs-10 col-sm-6 col-md-6 col-lg-6 submit"></div>
            <div class="col-xs-10 col-sm-6 col-md-6 col-lg-6 submit">
              <button class="pull-right" type="submit">Submit</button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-4 page-content">
      	<h3>Find us on map</h3>
      </div>
    </div>
  </div>
</div>

<?php
	//Footer
	include('footer.php');
?>
