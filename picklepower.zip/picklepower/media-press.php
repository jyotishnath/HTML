<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>media-press</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Media/Press</h1>
				<p><iframe id="vgtv001_1665473" src="http://cms.springboardplatform.com/embed_iframe/1985/video/1665473/vgtv001/vegtv.com/10/1/" frameborder="0" scrolling="no" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true" style="width:100%; height:464px;"></iframe></p>
				<p>&#8220;its no wonder people are looking for more healthful, sports nutrition options.&#8221; &#8211; <a href="http://vitaminretailer.com/new-twists-sports-nutrition/" target="_blank">Vitamin Retailer &#8211; New Twists on Sports Nutrition &#8211; April 2016</a></p>
				<p>&#8220;many athletes report that pickle juice works for them, and chronic crampers even drink it before as a preventative measure.&#8221; &#8211; <a href="https://runoregonblog.com/2016/04/14/run-oregon-test-kitchen-pickle-juice/" target="_blank">Test Kitchen &#8211; Run Oregon &#8211; April 2016</a></p>
				<p>&#8220;With key ingredients that are scientifically proven to block the neurological signal that triggers muscle cramps, the shot sets itself apart from other sports drinks on the market.&#8221; &#8211; <a href="http://www.preparedfoods.com/articles/117935-natural-extra-strength-pickle-juice-shot" target="_blank">Prepared Foods &#8211; 100% natural extra Strength Pickle Juice &#8211; April 2016</a></p>
				<p>&#8220;It&#8217;s Packed with Electrolytes&#8221; &#8211; <a href="http://running.competitor.com/2016/05/photos/all-natural-fuel-alternatives_150013" target="_blank">Competitor.com &#8211; All-Natural Fuel Alternatives &#8211; April 2016</a></p>
				<p>&#8220;The Pickle Juice Company elevates folk remedy anecdote to athletic recovery drink&#8221; <a href="http://www.nutraingredients-usa.com/Manufacturers/The-Pickle-Juice-Company-markets-sports-recovery-drinks" target="_blank">Nutra Ingredients USA &#8211; Pickle Juice &#8211; March 2016</a></p>
				<p>&#8220;Pickle Juice has long been known as a hangover cure, but now it’s gaining traction as a way for athletes to stop muscle cramps.&#8221; <a href="http://www.gamechanger.net/2016/03/cricket-flour-maple-water-pickle-juice-expo-west-new-innovations/" target="_blank">Game Changer &#8211; Expo West New Innovations &#8211; March 2016</a></p>
				<p>&#8220;It’s entirely possible that pickle juice is the solution to all your cycling woes&#8221; <a href="http://www.bikeradar.com/road/gear/article/11spd-this-weeks-new-bike-gear-dt-swiss-stans-notubes-endura-planet-x-46471/" target="_blank">Bike Radar &#8211; Best New Bike Gear &#8211; Feb 2016</a></p>
				<p>&#8220;Sports drinks go natural&#8221; <a href="http://hospitalitytimes.ie/whats-hitting-the-shelves-matcha-teas-aquavit-and-sparkling-ocean-spray/" target="_blank">Hospitality Times &#8211; What&#8217;s hitting the shelves &#8211; Feb 2016</a></p>
				<p>“I used the 100% Natural Pickle Juice Sport product and swear by its benefits” <a href="http://www.medicaldaily.com/treating-muscle-cramps-pickle-juice-workout-supplement-371014" target="_blank">Medical Daily &#8211; Treating Muscle Cramps with Pickle Juice &#8211; Jan 2016</a></p>
				<p>“..if you’re prone to cramping, carrying a bottle with a bit of pickle juice may save the day.” <a href="http://www.bicycling.com/food/hydration/should-you-be-drinking-pickle-juice-while-riding" target="_blank">Bicycling &#8211; Should you be drinking pickle juice while riding &#8211; Jan 2016</a></p>
				<p>“Athletes swear by pickle juice’s scientifically proven benefits to exercise recovery.” <a href="https://www.dherbs.com/articles/diet-nutrition/did-you-know-this-about-pickle-juice/" target="_blank">DHerbs &#8211; did you know this about Pickle Juice &#8211; Jan 2016</a></p>
				<p>“Move over coconut water, there’s a new beverage taking center stage: pickle juice.”<a href="http://womensrunning.competitor.com/2016/01/nutrition/the-cure-youve-never-heard-of-for-muscle-cramps_52423" target="_blank">Women&#8217;s Running &#8211; Why runners should drink pickle juice &#8211; Jan 2016</a></p>
				<p>“your muscle cramps (and hangovers) are squelched way more quickly – so go out there and get it.” <a href="http://theawesomer.com/pickle-juice-sports-drink/350669/" target="_blank">The Awesomer &#8211; Awesome Stuff &#8211; Jan 2016</a></p>
				<p>“proven highly effective for the immediate relief of muscle cramping.”<a href="http://www.grindtv.com/random/5-oddly-effective-foods-athletes-cabinet/#G13DfGmWWTGgwhSv.97" target="_blank">Grind TV &#8211; 5 oddly effective foods for the athlete&#8217;s cabinet &#8211; Jan 2016 </a></p>
				<p>&#8220;Things that work to relieve the cramps are light stretching, rest, water, and pickle juice.&#8221; <a href="http://ralphmedema.blogspot.com/2015/12/does-pickle-juice-stop-cycling-leg.html" target="_blank">Ralf Medema Blogspot &#8211; Does Pickle Juice Stop cycling leg cramps &#8211; Dec 15</a></p>
				<p>“this may be the cramp buster you have been looking for.”<a href="http://mnbiketrailnavigator.blogspot.com/2015/10/interbike-2015-cool-bike-gear-part-1.html" target="_blank">MN bike Trail Navigator &#8211; Interbike 2015 Product revue &#8211; Oct 2015 </a></p>
				<p>“try Pickle Juice™. Not just any pickle juice, but Pickle Power Pickle Juice™”<a href="http://www.bikerumor.com/2015/09/28/ib15-nutrition-roundup-tasty-treats-from-endurox-pickle-power-honey-stinger-compete-six-nutrition-more/" target="_blank">Bike Rumor &#8211; IB15 nutrition roundup &#8211; Sep 2015</a></p>
				<p>&#8220;Believe it or not, pickle juice can relieve muscle cramps effectively and quickly.&#8221; <a href="http://blog.trainerroad.com/pickle-juice-stop-cramps/" target="_blank">Trainer Road &#8211; Pickle Juice to Stop Cramps &#8211; Sept 2014</a></p>
				<p>&#8220;The pickle juice works so rapidly,..&#8221; <a href="http://cyclingillustrated.com/category/sean-burke/" target="_blank">Cycling Illustrated &#8211; Got Cramps? &#8211; Nov 2014</a></p>
				<p><a href="http://www.mensjournal.com/food-drink/drinks/why-you-should-mix-pickle-juice-with-your-whiskey-or-tequila-20160216" target="_blank">Men&#8217;s Journal &#8211; Why You Should Mix Pickle Juice With your Whiskey or Tequila &#8211; Feb 2016</a></p>
				<p><a href="http://www.susiedrinksdallas.com/product-review-pickle-juice-chaser/" target="_blank">Debbie Drinks Dallas &#8211; Pickle Juice Chaser Product Review &#8211; Feb 2016</a></p>
				<p><a href="http://www.skyelyfe.com/2016/02/02/bar-cart/" target="_blank">Skylyfe &#8211; Here&#8217;s the final addition needed in your bar cart &#8211; Jan 2016</a></p>
				<p><a href="https://marriedandmarathoning.wordpress.com/2014/04/17/pickle-juice-for-sore-legs/" target="_blank">Married and Marathoning &#8211; Pickle Juice for Sore Legs &#8211; Apr 2014</a></p>
				<p><a href="http://roadbikeaction.com/tech-news/new-products/rbas-friday-five-product-revue-9" target="_blank">Road Bike Action &#8211; Product revue &#8211; Aug 2015</a></p>
				<p><a href="http://www.nutritionaloutlook.com/food-beverage/barley-water-and-pickle-juice-make-splash-functional-drinks" target="_blank">Nutritional Outlook &#8211; Barley Water and Pickle Juice Make a Splash in Functional Drinks &#8211; Dec 2015</a></p>
				<p><a href="http://www.texashomesforsale.com/articles/a-magic-formula-when-you-re-in-a-pickle" target="_blank">Texas Homes For Sale &#8211; A Magical formula for When you are in a Pickle &#8211; Jan 2016 </a></p>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>