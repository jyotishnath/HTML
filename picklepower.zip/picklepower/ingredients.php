<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>ingredients</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Ingredients</h1>
				<p>In ongoing efforts to provide consumers with the healthiest and most functional product available, The Pickle Juice Company refrains from including “non-functional” ingredients in our formulations to the best of our ability.</p>
				<p><span class="yellow-text">Ingredients:</span> Dual Filtered Water, Vinegar, Salt, Natural Dill Flavor, Potassium, Zinc, Vitamin C, Vitamin E</p>
				<p><span class="yellow-text">Nutrition Facts:</span></p>
				<p><span class="yellow-text">Extra Strength Pickle Juice Shots:</span> serving size: 2.5 fl oz (75 mL) (1 bottle), servings per container: 1, Amount per serving: Calories: 0, Total Fat: 0g (0% DV), Cholesterol 0mg (0% DV), Sodium: 470 mg (20% DV), Potassium: 20mg (1% DV), Total Carbohydrate: 0g (0% DV), Sugars: 0g, Protein: 0g, Vitamin C (8% DV), Vitamin E (8% DV), Zinc: 2mg (13% DV). Percent daily values (DV) are based on a 2,000 calorie diet.</p>
				<p><span class="yellow-text">Pickle Juice Sport (Original and 100% Natural):</span> serving size: 8 fl oz (240 mL) (one 8 oz bottle or 1/2 of 16 oz bottle). Amount per serving: Calories: 0, Total Fat 0g (0% DV), Cholesterol: 0g (0% DV), Sodium: 820 mg (38% DV), Potassium: 70 mg (2% DV), Total Carbohydrate: 0g (0% DV), Sugars 0g (0% DV), Protein: 0g, Vitamin C (30% DV), Vitamin E (30% DV), Zinc (40% DV)</p>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>