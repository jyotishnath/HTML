<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>scientific-study</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Scientific Study</h1>
				<h4>Suffering From Muscle Cramps? Pick Pickle Juice</h4>
				<p><strong>Ben Muessig Contributor</strong></p>
				<p>(June 14 2010) — Gatorade® isn’t the only greenish drink that athletes crave. A new study indicates that pickle brine could help athletes when they need it most. Researchers say the juice at the bottom of a pickle jar is more effective at staving off crippling muscle cramps than water. To prove the salty premise long believed by some trainers and serious athletes, scientists induced toe cramps in male college students after forcing the subjects to bike to the point of mild dehydration. The average cramp lasted about two minutes and 30 seconds.</p>
				<p><strong>The Pickle Juice Company</strong></p>
				<p>A new study has revealed that pickle brine might be more effective than sports drinks at treating muscle cramps, confirming a longstanding assumption in the sports world. Football players, cyclists and triathletes have been sipping dill-flavored drinks, including bottles of The Pickle Juice Company, for years. Those who downed the brine stopped complaining of cramping within 85 seconds — about 37 percent faster than the water drinkers and 45 percent faster than when they didn’t drink anything at all.</p>
				<p><strong>Dr. Kevin Miller</strong>, the lead author of the study, told the Times he thinks pickle brine helps cure cramps because it triggers a nerve reaction. In fact, pickle brine seemed to ease cramp pains so quickly that he doubts it even had time to leave athletes’ stomachs before it started to work. Instead, Miller and the other researchers argued that pickle juice might spark some kind of “neurally mediated reflex” that helps give the right cues to misfiring muscles, which are thought to cause cramps.</p>
				<p>Though the study offers some concrete proof that pickle juice can quickly treat muscle cramps, the salty drink is still just a drop in the ocean at major sporting events compared to water and other sports drinks.</p>
				<p>Med Sci Sports Exerc. 2010 May;42(5):953-61. doi: 10.1249/MSS.0b013e3181c0647e.</p>
				<p class="yellow-text">Reflex inhibition of electrically induced muscle cramps in hypohydrated humans.</p>
				<p>Miller KC1, Mack GW, Knight KL, Hopkins JT, Draper DO, Fields PJ, Hunter I.</p>
				<p class="yellow-text">Author information</p>
				<ul>
					<li>1Department of Health, Nutrition, and Exercise Sciences, North Dakota State University, Fargo, ND 58108-6050, USA. Kevin.C.Miller@ndsu.edu</li>
				</ul>
				<hr>
				<h4>Running on pickle juice: Marathoners find a sour solution to muscle cramps</h4>
				<p><strong>By Paul Morgan</strong></p>
				<p><strong>Dr. Rick Ganzi</strong>, of Holland, is an avid marathoner who had a problem when he first started running the grueling 26-mile races 15 years ago.</p>
				<p>The 46-year-old had a problem with muscle cramps.</p>
				<p>“In my first 10 marathons, I had five or six of them that were destroyed by muscle cramps,” he said. “I would feel good after about 20 miles, but then something would cramp, usually my calf, and I would have to stop and stretch before I could continue and then my time would be destroyed.</p>
				<p>“It got so bad that I almost gave up marathon running.”</p>
				<p>Then a bodybuilding friend told him that many of the competitors would eat pickles to help them from losing sodium and cramping up. Ganzi also likes to tell people about a National Football League game about 10 years ago between Philadelphia and Dallas that was won by the Eagles on an extremely hot day.  Philadelphia didn’t cramp up as much as Dallas because the Eagles drank several ounces of pickle juice for several days before the game.</p>
				<p>Some marathon runners depend on pickle juice to provide the sodium their bodies lose in a long race.</p>
				<p>“So I started drinking pickle juice before a marathon,” he said. “I didn’t cramp up and I had my best time ever.”</p>
				<p>After drinking the juice for several years, he thought that maybe it wasn’t the juice that was keeping him from cramping, so he didn’t drink it prior to a race, “and I cramped up, so that told me there was something to the pickle juice that was helping me out,” Ganzi said.</p>
				<p>“The juice is a niche market for athletes who do an event for several hours. It has a limited role, to help people who run marathons, ultra-marathons (50-mile-plus events) and Ironman triathlons. It’s not for the everyday person who works out for an hour or so.”</p>
				<p>When he helped start the Grand Rapids Marathon in 2004, Ganzi found a sponsor in Golden Pickle Juice of Golden, Texas.</p>
				<p>Ganzi has looked at data about marathon runners who lose a lot of sodium after a race.</p>
				<p>“There was one study that enrolled runners in the Boston Marathon, and what they found was that 15 percent had low sodium levels when they crossed the finish line and some of them were life-threateningly low,” he said. “It’s called hyponatremia.”</p>
				<p>One problem with pickle juice is that some people hate the taste. Several races have gone to a better-tasting broth with a strong concentration of sodium to help runners.</p>
				<p>Ganzi now swears by the juice. He recently completed the 56-mile Comrades Marathon in South Africa without having muscle cramps.</p>
				<p>“In a race like that, a runner can lose 20-to-25 grams of sodium, which is around 20 percent of your body’s sodium,” he said.</p>

				<div class="box-lay">
					<p><span class="yellow-text">Metro Health Grand Rapids Marathon</span></p>
					<p>When: Oct. 18</p>
					<p>Distances: Full marathon (26.2 miles); Half-marathon (13.1 miles); Marathon relay (26.2 miles by three to five runners who will run about four-to-six miles apiece).</p>
					<p>Entry limits: 2,000 for the full marathon; 1,500 half-marathon; 120 teams.</p>
					<p>To register: Go to <a href="http://www.grandrapidsmarathon.com/" target="_blank">www.grandrapidsmarathon.com</a></p>
				</div>
			</div><!-- Left Section -->
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>




div.sap>div.dhaj>ul.test>li.item$@*4>a[#]{hfdhalkfhlajk}




