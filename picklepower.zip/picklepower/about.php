<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>about-us</li>
				</ul>
			</div>
			<div class="col-md-6 page-content">
				<h1>Pickle Juice ® Sport</h1>
				<p>GET THE EDGE YOU NEED TO FINISH…</p>
				<p>Supplying athletes since 2000…</p>
				<p>It is truly an honor to be a part of a company whose philisophy is only one thing: To help you achieve your best in what you do. When springtime rolls around, we are excited as the amateur and professional athletes awaken from a wintertime slumber and put on their running shoes, dust off the bicycle, grab a tennis racquet from the closet. <span class="yellow-text">Pickle Juice ® Sport</span> has been dedicated to ensuring success in your activity of choice.</p>
				<p>Over the past 12 years we have had the privilege of meeting truly great people whose use the product then share their success with others. It is through our loyal customers and the support of our retailers that <span class="yellow-text">Pickle Juice ® Sport</span> has been able to help so many. Thank you for your trust in <span class="yellow-text">Pickle Juice ® Sport</span></p>
			</div>
			<div class="col-md-6">
				<a href="javascript:void(0);"><img src="assets/img/aboutusimg.png" alt=""></a>
				<h3 class="read-review pull-right"><a href="javasxript:void(0);">Read Reviews</a></h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>