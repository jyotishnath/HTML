<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
	<div class="row">
		<div class="col-md-12 page-bg">
			<div class="breadcrub pull-right yellow-text">
				<ul>
					<li><a href="javascript:void(0);">Home /</a></li>
					<li>internet-sales-refund-policy</li>
				</ul>
			</div>
			<div class="col-md-9 page-content">
				<h1>Internet Sales Refund Policy</h1>
				<p>Products that have been paid for but not yet shipped are available for a 100% refund of product and outbound shipping charges. Provision of a reason for refund is not required. You must notify us as quickly as possible because orders are customarily shipped the day the order is received. Immediate reaction to your request is not guaranteed because of a possible conflict with our normal daily responsibilities.</p>
				<p>If an order has been shipped then a (partial or full) refund on the product may be granted but the outbound shipping charges will not be refunded. A suitable reason for the refund must be provided to us by email within thirty (30) days of the original outbound shipping date and its acceptance will be at the sole discretion of The Pickle Juice Company. Complaint about the flavor profile will not qualify as a valid reason for refund.</p>
				<p>Product that has been shipped must be returned to The Pickle Juice Company at the customer’s expense within forty (40) days of the original outbound shipping date. The Pickle Juice Company will determine, at its sole discretion, if the product was returned in suitable condition. Precaution should be taken in packaging to ensure the parcel will protect the product and it is suitable for shipping.</p>
				<p>Once the product has been received, with inbound shipping charges paid by the customer, a determination will be made regarding the reason for refund request, the suitability of returned product, and compliance with time limits. Within ten (10) days after return receipt of the product an appropriate refund may then be credited back to the bank card originally used for the purchase transaction. If a refund is denied then an email will be sent to the customer outlining the reason(s) for the denial.</p>
			</div>
			<div class="col-md-3 page-content">
				<h3>Widget Title</h3>
			</div>
		</div>
	</div>
</div>

<?php
	//Footer
	include('footer.php');
?>