<?php 
	//Header
	include('header.php'); 
?>

<div class="container-fluid no-pading page-banner"><a href="javascript:void(0);"><img src="assets/img/banner-sub.jpg" alt=""></a></div>

<div class="container">
  <div class="row">
    <div class="col-md-12 page-bg">
      <div class="breadcrub pull-right yellow-text">
        <ul>
          <li><a href="javascript:void(0);">Home /</a></li>
          <li>gallery</li>
        </ul>
      </div>
      <div class="col-md-9 page-content">
        <h1>Gallery</h1>
  <section>
    <div class="col-md-12">
      <div class="col-md-6 no-pading gallery">
        <a href="assets/gallery/artep-team-pic.jpg" data-lightbox="example-set" data-title="Artep-Team Pic"><img class="img-responsive" src="assets/gallery/artep-team-pic.jpg" alt=""/></a>
      </div>

      <div class="col-md-6 no-pading gallery">
        <a href="assets/gallery/hhh-booth.jpg" data-lightbox="example-set" data-title="HHH Booth"><img class="img-responsive" src="assets/gallery/hhh-booth.jpg" alt="" /></a>
      </div>

      <div class="col-md-6 no-pading gallery">
        <a href="assets/gallery/interbike-booth.jpg" data-lightbox="example-set" data-title="Interbike Booth"><img class="img-responsive" src="assets/gallery/interbike-booth.jpg" alt="" /></a>
      </div>


      <div class="col-md-6 no-pading gallery">
        <a href="assets/gallery/tf-finish.jpg" data-lightbox="example-set" data-title="TF Finish"><img class="img-responsive" src="assets/gallery/tf-finish.jpg" alt="" /></a>
      </div>

      <div class="col-md-6 no-pading gallery">
        <a href="assets/gallery/pjc-bmx.jpg" data-lightbox="example-set" data-title="PJC BMX"><img class="img-responsive" src="assets/gallery/pjc-bmx.jpg" alt="" /></a>
      </div>

      <div class="col-md-6 no-pading gallery">
        <a href="assets/gallery/warehouse.jpg" data-lightbox="example-set" data-title="Warehouse"><img class="img-responsive" src="assets/gallery/warehouse.jpg" alt="" /></a>
      </div>
    </div>
  </section>
  </div>
      <div class="col-md-3 page-content">
        <h3>Widget Title</h3>
      </div>
    </div>
  </div>
</div>

	

  <script src="assets/js/lightbox-plus-jquery.min.js"></script>

<?php
	//Footer
	include('footer.php');
?>